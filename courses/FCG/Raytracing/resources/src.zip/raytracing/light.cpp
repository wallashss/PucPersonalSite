#include "light.h"

Light::Light() :
    position(0,0,0),
    color(1,1,1)
{
}
