//
//  functions.h
//  SeismicImage
//
//  Created by Wallas Henrique Santos on 14/06/14.
//  Copyright (c) 2014 Wallas Henrique Santos. All rights reserved.
//

#pragma once

#include <iostream>
#include "image.h"
#include "QualityThreshold.h"

Image * nonMaximalSupression(Image * inputImage);

std::vector<qt::Pixel> image2pixelsVector(Image * inputImage);

Image * qtImage2Image(std::vector<qt::Pixel> inputImage, int width, int height);

Image * verticalSmoothImage(Image * inputImage);

Image * qtCluster2Image(std::vector<std::vector<qt::Pixel> > clusters,int w,int h);
