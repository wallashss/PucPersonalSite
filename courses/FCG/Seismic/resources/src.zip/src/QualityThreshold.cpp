#include "QualityThreshold.h"
#include <cmath>

namespace qt {


Pixel::Pixel( int posX, int posY)
{
	this->posX = posX; 
	this->posY = posY;
	this->tempValue = 0;
}

Pixel::Pixel()
{
}


/* Fun��o utilizada para colocar os pixels alocados no final do vector */
    std::vector<Pixel>* QualityThreshold::swapPosition(std::vector<Pixel>* pixel, int position)
{

	auto size = pixel->size() - 1; //tamanho de 0 ao ultimo ponto;

	Pixel pixelToRemove = pixel->at(position);
	Pixel pixelToMove = pixel->at(size);
	
	pixel->at(position) = pixelToMove;
	pixel->at(size) = pixelToRemove;

	return pixel;

}


    double QualityThreshold::getMedia(std::vector<Pixel> pixels)
{
//	double maior = - 10000,  menor = 2000;
	double soma = 0;
	for(int i = 0 ; i < pixels.size() ; i++)
	{
		soma+= pixels[i].tempValue;
	}
	return  soma / pixels.size();
}


//double QualityThreshold::getDistance(Pixel p1 , Pixel p2){
//
//	double diferenceX = (p2.posX - p1.posX); //diferen�a entre os valores de x
//	double diferenceY = (p2.posY - p1.posY); //diferen�a entre os valores de y
//	
//
//	return sqrt( pow(diferenceX,2) + pow(diferenceY,2) ) ; // retorna a distancia euclidiana entre os dois pontos 
//
//
//}


/* Algoritmo em si, A partir de um vetor de Pixel retorna o melhor cluster poss�vel dentro do limiar de similaridade escolhido */
    std::vector<Pixel> QualityThreshold::getBetterCandidate(std::vector<Pixel>* pixels, double threshold)
{

	
    std::vector<std::vector<Pixel> > candidatos; // armazena todos os clusters candidatos
    std::vector<Pixel> candidatoAtual; // armazena o cluster candidato atual
	
	// mant�m o controle de n�meros candidatos a que pontos foram atribu�dos
    std::vector<int> numeroCandidatos (pixels->size());
	int totalpontosAlocados = 0; // n�mero total de pontos j� atribu�dos a candidatos
    int numeroAtualCandidato = 0; //n�mero atual candidato

    for (int i = 0; i < (int)pixels->size(); i++)
    {
        if (totalpontosAlocados == pixels->size())
            break; // n�o h� necessidade de continuar mais

        if (numeroCandidatos[i] > 0 )
            continue; // ponto j� atribu�do a um candidato ou nao � >= a media

        numeroAtualCandidato++;
		candidatoAtual = std::vector<Pixel>(); // criar um cluster de novo candidato
		candidatoAtual.push_back(pixels->at(i));

        numeroCandidatos[i] = numeroAtualCandidato;
        totalpontosAlocados++;
		Pixel pontoMaisRecente = pixels->at(i); // 
		
		for (int j = i + 1; j < (int)pixels->size(); j++)
        {

            if (totalpontosAlocados == pixels->size())
                break; //  n�o h� necessidade de continuar mais
            
			if (numeroCandidatos[j] > 0)
                continue; // ponto j� atribu�do a um candidato

			//double distQuadrado = Distancia(pontoMaisRecente, pontos->at(j));

//			double distance = getDistance(pontoMaisRecente, pixels->at(j));
			double difTemp = abs(pontoMaisRecente.tempValue - pixels->at(j).tempValue);
			if (  difTemp <= threshold  ){
                candidatoAtual.push_back(pixels->at(j));
                numeroCandidatos[j] = numeroAtualCandidato;
                totalpontosAlocados++;
				
            }
        }

        candidatos.push_back(candidatoAtual);
		
    }
	
    // agora encontrar o cluster candidato com o maior n�mero de pontos
    int maxpontos = -1; // valor muito pequeno
    int numeroMelhorCandidato = 0; // idem

    for (int i = 0; i < (int)candidatos.size(); i++)
    {
        if ((int)candidatos[i].size() > maxpontos)
        {
            maxpontos = candidatos[i].size();
            numeroMelhorCandidato = i + 1; // contagem de 1, em vez de 0
        }
    }
	
    // Iterando para tr�s para evitar problemas de indexa��o, remover os pontos do melhor candidato da lista de pontos
    // Este ser� automaticamente persistido ao interlocutor como Lista <Ponto> � um tipo de refer�ncia
    //cout<<"Antes -> "<<pontos->size()<<endl;
	
	for (int k = (numeroCandidatos.size() - 1); k >= 0; k--)
    {
        if (numeroCandidatos[k] == numeroMelhorCandidato){
			pixels = swapPosition(pixels,k);
			pixels->pop_back();
		}
    }
	//cout<<"Depois -> "<<pontos->size()<<endl;
    
	return candidatos[numeroMelhorCandidato - 1];
}


/* Pega os melhores clusters enquanto houver pixels no vetor */
    std::vector<std::vector<Pixel> > QualityThreshold::getClusters(std::vector<Pixel> pixels, double threshold)
{
	std::vector<std::vector<Pixel> > clusters;

	while(pixels.size() > 0 )
	{
		std::vector<Pixel> betterCandidate = getBetterCandidate(&pixels,threshold);
		clusters.push_back(betterCandidate);
	}
	return clusters;
}


/* Fun��o de chamada */
std::vector<std::vector<Pixel> > QualityThreshold::qualityThreshold(std::vector<Pixel> pixels, double threshold,  int min, int max)
{
	double media = getMedia(pixels);

	std::vector<std::vector<Pixel> > clusters = getClusters(pixels, threshold);
	
//	vector<vector<Pixel> > growthClusters = growth(clusters);
//	vector<vector<Pixel> > myClusters;
//
//	
//	for( int i = 0 ; i < growthClusters.size() ; i++ )
//	{
//		if( growthClusters[i].size() > min  )
//		{
//			if( growthClusters[i].size() < max )	
//			{	
//				if( growthClusters[i].at(0).tempValue >= media )
//					myClusters.push_back(growthClusters[i]);
//			}
//
//
//		}
//	}

	return clusters;
}


/* Crescimento de Regi�o 
	Separa partes de um mesmo cluster que n�o possuem liga��o espacial */
std::vector<std::vector<Pixel> > QualityThreshold::growth(std::vector<std::vector<Pixel> > clusters)
{
	std::vector<std::vector<Pixel> > growthClusters;

	std::vector<int> *controlvar;

	std::vector<Pixel> auxCluster;

	int pos;
	int alloc;

	for(int i = 0 ; i < clusters.size(); i++ ) // percorre todos os clusters
	{
		alloc = 0;
		controlvar = new std::vector<int>(clusters[i].size()); // cria um vetor de controle do mesmo tamanho do cluster atual
			// controlvar � utilizada pra manter o controle dos vizinhos j� alocados;
		while( alloc < clusters[i].size() )
		{
			// la�o pega o primeiro valor nao alocado e retorna como seed
			for( int k = 0 ; k < controlvar->size() ; k++ )
			{
				if( controlvar->at(k) == 0 ) 
				{
					pos = k;
					break;
				}
	
			}
			
			auxCluster.push_back(clusters[i].at(pos)); // coloca o seed no novo vetor
			controlvar->at(pos) = 1; // marca a posi�ao da seed como 1 pois j� est� dentro
			alloc++;

			for( int j = 0 ; j < auxCluster.size() ; j++) 
			{
				std::vector<int> neighbors_pos = getNeightbors(clusters[i], auxCluster[j]); // pega os vizinhos da seed
				if( neighbors_pos.size() > 0 ) 
				{
					for(int z = 0 ; z < neighbors_pos.size() ; z++)
					{
						if( controlvar->at(neighbors_pos[z]) == 0 ) // se ainda nao foi alocado
						{	
							auxCluster.push_back(clusters[i].at(neighbors_pos[z])); // coloca  o vizinho no novo vetor
							controlvar->at(neighbors_pos[z]) = 1; // marca como alocado
							alloc++; // incrementa a variavel de controle
						}
					}
				}
			}
			growthClusters.push_back(auxCluster); // adiciona o novo cluster formado � cole��o de clusters
			auxCluster.clear(); // limpa o vetor auxiliar;
		}	
		delete controlvar;
	}

	return growthClusters;
}

/* Pega os vizinhos de um pixel a partir de sua posi��o */
std::vector<int> QualityThreshold::getNeightbors(std::vector<Pixel> cluster, Pixel p)
{
	/* Pega 8-vizinhan�a do pixel p */
	Pixel
		n1( p.posX + 1, p.posY ),
		n2( p.posX - 1, p.posY  ),
		n3( p.posX, p.posY + 1   ),
		n4( p.posX , p.posY - 1  ),
		n5( p.posX - 1, p.posY - 1  ),
		n6( p.posX - 1, p.posY + 1  ),
		n7( p.posX + 1, p.posY - 1  ),
		n8( p.posX + 1, p.posY + 1  );
			

	std::vector<int> neighbors_positions;

	/* Percorre o vetor procurando os vizinhos */
	for(int i = 0; i < cluster.size(); i++)
	{
		
			// Se o ponto que est� sendo lido for igual a posi��o pre-estabelecida dos vizinhos, colocamos eles na lista de vizinhos
		if( cluster[i].posX == n1.posX && cluster[i].posY == n1.posY  ) neighbors_positions.push_back(i); 
		if( cluster[i].posX == n2.posX && cluster[i].posY == n2.posY  ) neighbors_positions.push_back(i);
		if( cluster[i].posX == n3.posX && cluster[i].posY == n3.posY  ) neighbors_positions.push_back(i);
		if( cluster[i].posX == n4.posX && cluster[i].posY == n4.posY  ) neighbors_positions.push_back(i); 
		if( cluster[i].posX == n5.posX && cluster[i].posY == n5.posY  ) neighbors_positions.push_back(i); 
		if( cluster[i].posX == n6.posX && cluster[i].posY == n6.posY  ) neighbors_positions.push_back(i); 
		if( cluster[i].posX == n7.posX && cluster[i].posY == n7.posY  ) neighbors_positions.push_back(i); 
		if( cluster[i].posX == n8.posX && cluster[i].posY == n8.posY  ) neighbors_positions.push_back(i); 
		
	}

	/*Retorna o vetor de vizinhos*/
	return neighbors_positions;

}
}
