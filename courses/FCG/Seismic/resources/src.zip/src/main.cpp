//
//  main.cpp
//  SeismicImage
//
//  Created by Wallas Henrique Santos on 24/05/14.
//  Copyright (c) 2014 Wallas Henrique Santos. All rights reserved.
//

#include <iostream>
#include <sstream>
#include "image.h"
#include "functions.h"
#include "QualityThreshold.h"


int main(int argc, const char * argv[])
{
    
    if(argc <2)
    {
        std::cout << "Enter a valid input file" <<std::endl;
        return EXIT_SUCCESS;
    }
    std::string imageName(argv[1]);
    Image * simImage = imgReadSIM(imageName.c_str());
    
    int w = imgGetWidth(simImage);
    int h = imgGetHeight(simImage);
    
    imgWriteBMP("original.bmp", simImage);
    Image * smoothImage = verticalSmoothImage(simImage);
    imgWriteBMP("smooth.bmp", smoothImage);
    
    
    std::vector<qt::Pixel> qtImage = image2pixelsVector(smoothImage);
    
    qt::QualityThreshold qt;
    std::vector<std::vector<qt::Pixel> > clusters = qt.qualityThreshold(qtImage, 700, 2, 50);
    
    Image * colorClusters = qtCluster2Image(clusters,w,h);
    imgWriteBMP("_qtClusters.bmp", colorClusters);
    
    for (auto i=0; i<clusters.size(); i++)
    {
        std::ostringstream oss;
        oss << "image_" << i << ".bmp";
        std::vector<qt::Pixel> cluster =clusters[i];
        Image * clusterImage = qtImage2Image(cluster, w, h);
        
        char buffer[100];
        strcpy(buffer, oss.str().c_str());
        imgWriteBMP(buffer, clusterImage);
        
    }
    
    return 0;
}

