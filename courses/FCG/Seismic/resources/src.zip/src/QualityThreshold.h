#pragma once
#include <vector>
#include <iostream>
//#include <Qt>

//using namespace std;

namespace qt {
class Pixel{
public:
	int posX; // posi��o eixo x
	int posY; // posi��o eixo y
	double tempValue; // valor de temperatura naquele ponto
	Pixel( int posX, int posY);
	Pixel();
};


class QualityThreshold
{
public:
	
	/* Aplica o Quality Threshold */
    std::vector<std::vector<Pixel> > qualityThreshold(std::vector<Pixel> , double threshold, int min , int max);

private:
	/* Troca dois pixels de lugar no vetor */
    std::vector<Pixel>* swapPosition(std::vector<Pixel>* , int);

	/* Calcula a distancia entre dois pixels */
//	double getDistance(Pixel , Pixel);

	double getMedia(std::vector<Pixel> pixels);

	/* Obtem o melhor candidato a cluster */
    std::vector<Pixel> getBetterCandidate(std::vector<Pixel>* , double threshold1);

	/* Obtem os clusters da imagem */
    std::vector<std::vector<Pixel> > getClusters(std::vector<Pixel> , double threshold);

    std::vector<std::vector<Pixel> > growth(std::vector<std::vector<Pixel> > clusters); // crescimento de regiao

    std::vector<int> getNeightbors(std::vector<Pixel> cluster, Pixel p); // Pega as posi��es dos vizinhos
};
}

