ColorGamut
==========

Gamut of optimal colors
